for ((i=0; i<26; i++)) do
	num=$(expr $RANDOM % 27)
	case $num in
		0) echo "a";;
		1) echo "b";;
		2) echo "c";;
		3) echo "d";;
		4) echo "e";;
		5) echo "f";;
		6) echo "g";;
		7) echo "h";;
		8) echo "i";;
		9) echo "j";;
		10) echo "k";;
		11) echo "l";;
		12) echo "m";;
		13) echo "n";;
		14) echo "o";;
		15) echo "p";;
		16) echo "q";;
		17) echo "r";;
		18) echo "s";;
		19) echo "t";;
		20) echo "u";;
		21) echo "v";;
		22) echo "w";;
		23) echo "x";;
		24) echo "y";;
		25) echo "z";;
	esac
done
